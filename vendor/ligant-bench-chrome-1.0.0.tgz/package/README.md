# @ligant/bench-chrome

The header and footer every [Ligant Bench Tool](https://benchtools.ligant.ai/) shares: the Ligant lockup, the tool switcher, the standard privacy statement, the citation block and the licence. A tool supplies only what is its own. Everything else is written once, here.

- **Framework-free.** Every renderer returns an HTML string. Plain-JS tools set it as `innerHTML`; React tools use the thin wrappers in `@ligant/bench-chrome/react`.
- **Contacts nothing.** No network primitive, no storage, no runtime dependency. The only addresses it embeds are `https://benchtools.ligant.ai`, `https://ligant.ai/`, `https://ligant.ai/privacy` and the tool's own repository, which the tool passes in.
- **Built into each tool, not loaded at runtime.** Each tool pins a version, so a deployed page is reproducible from its own commit.
- **Vendored, so the tools stay buildable by anyone.** This repository is private. Each release is packed into one file that is committed into every tool's own repository, so a reader who clones a tool can install and run it with no access to this repository and no network. The code is Apache-2.0, like the tools it ships in.

## Install

In a tool's repository, with the release tarball copied into `vendor/`:

```sh
npm install ./vendor/ligant-bench-chrome-1.0.0.tgz
```

Then import the stylesheet once from the tool's entry point:

```js
import '@ligant/bench-chrome/chrome.css';
```

The stylesheet uses the suite's design tokens (`--border`, `--text-primary`, `--brand-teal`, `--surface`, `--font`, `--mono` and the rest), which every tool defines. Every selector is scoped under `.masthead` or `.site-footer`.

## What a tool supplies

| Option | Header | Footer | Example |
|---|---|---|---|
| `path` | ✓ | | `'/dilution-planner/'`, the tool's own mount point; the switcher marks it as the current page |
| `title` | ✓ | | `'Dilution Planner'` |
| `description` | ✓ | | a string, or an array of paragraphs |
| `repoUrl` | | ✓ | `'https://github.com/Ligant-AI/C3-Dilution-Planner'`, the tool's own repository |
| `citations` | | ✓ | `[{ lead, title, tail, what }]`, shown as lead + *title* + tail and copied as the same |
| `disclaimer` | | ✓ | `'Research use only. Not qualified for GxP decision-making.'` |
| `citationNote` | | optional | default `'Cite the software as below.'` |
| `citationFootnote` | | optional | a note under the citations |
| `localCopyHtml` | | optional | trusted markup after the repository link; default `Clone it and <code>npm run dev</code> for a local copy.` |

Keep `repoUrl` in the tool's own config (`site.ts` or `config.js`), where its checks and `CITATION.cff` can see it.

## Plain JS

```html
<header class="masthead" id="site-header"></header>
…
<footer class="site-footer" id="site-footer"></footer>
```

```js
import { renderHeader, renderFooter, bindCopy } from '@ligant/bench-chrome';

document.getElementById('site-header').innerHTML = renderHeader({ path, title, description });
const footer = document.getElementById('site-footer');
footer.innerHTML = renderFooter({ repoUrl, citations, disclaimer });
bindCopy(footer);
```

## React

```tsx
import { SuiteHeader, SuiteFooter, LigantMark } from '@ligant/bench-chrome/react';

<SuiteHeader path={TOOL_PATH} title="Antigen Density Calculator" description="Quantifies…" />
…
<SuiteFooter repoUrl={REPO_URL} citations={[…]} disclaimer="Research use only. …" />
```

`LigantMark` renders the mark alone, for a colophon.

## Changing the chrome

1. Change it here, add a test, and bump the version in `package.json`.
2. Commit, then `git tag vX.Y.Z` and push the tag.
3. Roll it out: `scripts/rollout.sh X.Y.Z` packs the release and, for each live tool, copies the tarball into `vendor/`, updates the dependency, runs the tool's own checks, and opens a pull request. Nothing is merged or deployed by the script; review and merge each pull request, then deploy.

A header lists a new tool only once that tool's own deployment has been rebuilt, so add a tool to `TOOLS` only once it is live.

## Licence

Apache License, Version 2.0. See [LICENSE](LICENSE).
