export declare const SITE_URL: 'https://benchtools.ligant.ai'
export declare const LIGANT_URL: 'https://ligant.ai/'
export declare const PRIVACY_URL: 'https://ligant.ai/privacy'
export declare const SUITE_LABEL: string
export declare const PRIVACY_STATEMENT: string
export declare const OPEN_SOURCE_STATEMENT: string
export declare const ENTERPRISE_STATEMENT: string
export declare const LEGAL_ENTITY: string
export declare const ADDRESS: readonly string[]
export declare const CONTACT_EMAIL: string

export interface SuiteTool {
  readonly id: string
  /** Label in the tool switcher. */
  readonly label: string
  /** Mount point under SITE_URL, with a trailing slash. */
  readonly path: string
}
export declare const TOOLS: readonly SuiteTool[]

export interface HeaderOptions {
  /** This tool's own mount point, e.g. '/dilution-planner/'. */
  path: string
  title: string
  /** One paragraph, or several, under the title. Plain text. */
  description?: string | string[]
}

export interface Citation {
  lead: string
  title: string
  tail: string
  /** Names the work in the copy button's label. Default 'software'. */
  what?: string
}

export interface FooterOptions {
  /** This tool's own repository. */
  repoUrl: string
  citations: Citation[]
  /** The bold line that ends the licence paragraph. */
  disclaimer: string
  citationNote?: string
  citationFootnote?: string
  /** Trusted markup for the sentence after the repository link. */
  localCopyHtml?: string
}

export interface MarkOptions {
  size?: number
  variant?: 'tile' | 'plain'
  title?: string
}

export declare function suiteUrl(path: string): string
export declare function escapeHtml(s: unknown): string
export declare function markSvg(options?: MarkOptions): string
export declare function lockupHtml(size?: number): string
export declare function markDataUri(): string
export declare function renderHeader(options: HeaderOptions): string
export declare function renderFooter(options: FooterOptions): string
export declare function bindCopy(root: Element): () => void

/** The newsletter signup. Rendered at the top of renderFooter; bindCopy wires it. */
export declare const NEWSLETTER_HOSTS: readonly string[]
export declare const NEWSLETTER_ENDPOINT: string
export declare const NEWSLETTER_TEXT: string
export declare function renderNewsletter(): string
export declare function bindNewsletter(root: Element): () => void

/** The privacy choice banner. Idempotent; started by bindCopy and SuiteFooter. */
export declare function initConsent(): void
export declare const GA_ID: string
export declare const GA_SCRIPT_URL: string
export declare const CONSENT_KEY: string
export declare const CONSENT_VERSION: string
export declare const BANNER_TEXT: string
export declare const PRIVACY_CHOICES_URL: string
