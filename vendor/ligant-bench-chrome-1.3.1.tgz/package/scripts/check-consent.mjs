#!/usr/bin/env node
// Checks a Bench Tool page's privacy choice, and that nothing typed into the
// tool reaches Google, in a real browser.
//
//   node scripts/check-consent.mjs <page URL> [<page URL> ...]
//   node scripts/check-consent.mjs --live      every tool at benchtools.ligant.ai
//   node node_modules/@ligant/bench-chrome/scripts/check-consent.mjs --serve dist
//                                              a tool's own build, served inside
//                                              the test browser AS https://
//                                              benchtools.ligant.ai/ (the banner
//                                              runs only on hosted addresses);
//                                              index.html's meta CSP applies
//
// For each page:
//   1. First load: the banner is shown, and there is no Google request, no
//      cookie and no storage.
//   2. A sentinel is typed into every field, Allow is clicked, the sentinel is
//      typed again and each field is left (so change and blur fire). The tag
//      must load, and no request to any host may carry the sentinel in its URL
//      or body. This is what keeps "your inputs never leave your browser" true
//      with Google Analytics on the page.
//   3. GA cookies are host-only. Withdrawing through "Privacy choices" deletes
//      them, and the next load makes no Google request.
//   4. A Global Privacy Control signal: no banner, no Google.
//   5. The newsletter signup (the one field that is meant to send what is
//      typed): nothing is sent on load or when Enter is pressed in a tool
//      field, and submitting sends one POST to /api/subscribe carrying the
//      email, the consent and the honeypot, and nothing typed into the tool.
//      The address appears in no other request. The POST is intercepted, so
//      no confirmation email is ever sent.
// Every Google Analytics hit is recorded and aborted, so a check never counts
// as a visit.
import { chromium } from 'playwright';
import { createServer } from 'node:http';
import { readFileSync, existsSync, statSync } from 'node:fs';
import { join, extname, resolve } from 'node:path';
import { SITE_URL, TOOLS } from '../src/index.js';

const args = process.argv.slice(2);
let server = null;
let serveRoot = null;
let serveTypes = {};
// With --serve, every request to the suite's origin is answered from the build
// directory and never reaches the network.
const LOCAL_COPY = 'http://127.0.0.1:1';
async function serveFromBuild(context) {
  if (!serveRoot) return;
  for (const origin of [SITE_URL, LOCAL_COPY]) await context.route(`${origin}/**`, (route) => {
    let file = join(serveRoot, decodeURIComponent(new URL(route.request().url()).pathname));
    if (!file.startsWith(serveRoot) || !existsSync(file) || statSync(file).isDirectory()) file = existsSync(join(file, 'index.html')) ? join(file, 'index.html') : join(serveRoot, 'index.html');
    route.fulfill({ status: 200, contentType: serveTypes[extname(file)] || 'application/octet-stream', body: readFileSync(file) });
  });
}
let urls = args.includes('--live') ? TOOLS.map((t) => `${SITE_URL}${t.path}`) : args.filter((a) => !a.startsWith('--'));
const serveAt = args.indexOf('--serve');
if (serveAt !== -1) {
  const root = resolve(args[serveAt + 1] || 'dist');
  if (!existsSync(join(root, 'index.html'))) { console.error(`--serve: ${root}/index.html not found; build first`); process.exit(2); }
  const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.json': 'application/json', '.png': 'image/png', '.txt': 'text/plain' };
  serveRoot = root;
  serveTypes = TYPES;
  const base = `${SITE_URL}/`;
  urls = [base, `${base}?q=LIGANTSENTINELQUERY#LIGANTSENTINELHASH`];
}
if (!urls.length) { console.error('usage: check-consent.mjs <page URL> ... | --live'); process.exit(2); }

const GOOGLE = /(^|\.)(googletagmanager\.com|google-analytics\.com|analytics\.google\.com|doubleclick\.net|google\.com)$/;
const HIT = /google-analytics\.com|analytics\.google\.com|doubleclick\.net|google\.com\/(g|ccm)\//;
const TEXT_SENTINEL = 'LIGANTSENTINEL';
const NUM_SENTINEL = '7731.4429';
// Every sentinel in plain, URL-encoded, base64 and base64url form.
const b64 = (x) => Buffer.from(x).toString('base64').replace(/=+$/, '');
const b64url = (x) => b64(x).replace(/\+/g, '-').replace(/\//g, '_');
const FORMS = [TEXT_SENTINEL, NUM_SENTINEL, encodeURIComponent(NUM_SENTINEL), '7731%2E4429',
  b64(TEXT_SENTINEL).slice(0, 16), b64url(TEXT_SENTINEL).slice(0, 16), b64(NUM_SENTINEL).slice(0, 10), b64url(NUM_SENTINEL).slice(0, 10)];
const leaks = (s) => FORMS.some((f) => s.includes(f));

let failures = 0;
const fail = (m) => { console.error(`  FAIL  ${m}`); failures++; };
const ok = (m) => console.log(`  ok    ${m}`);

const browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_PATH || undefined });

async function open(url, { gpc } = {}) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  if (gpc) await context.addInitScript(() => Object.defineProperty(Navigator.prototype, 'globalPrivacyControl', { get: () => true }));
  await serveFromBuild(context);
  const page = await context.newPage();
  const all = [];
  const google = [];
  await page.route(HIT, (route) => { route.abort(); });
  page.on('request', (r) => {
    const entry = { url: r.url(), body: r.postData() || '' };
    // The page's own navigations carry whatever address the test opened; they
    // are the browser loading the page, not the page sending anything.
    const own = r.isNavigationRequest() && new URL(r.url()).origin === new URL(url).origin;
    if (!own) all.push(entry);
    if (GOOGLE.test(new URL(r.url()).hostname)) google.push(entry);
  });
  const blocked = [];
  page.on('console', (m) => { if (/Content Security Policy/i.test(m.text()) && /google/i.test(m.text())) blocked.push(m.text().slice(0, 160)); });
  await page.goto(url, { waitUntil: 'networkidle', timeout: 60000 });
  await page.waitForTimeout(800);
  return { context, page, all, google, blocked };
}

async function typeEverywhere(page) {
  const fields = page.locator('input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=file]):not([type=button]):not([type=submit]), textarea');
  const n = await fields.count();
  let typed = 0;
  for (let i = 0; i < n; i++) {
    const f = fields.nth(i);
    if (!(await f.isVisible().catch(() => false)) || !(await f.isEditable().catch(() => false))) continue;
    // The signup is checked on its own, in step 5.
    if (await f.evaluate((e) => Boolean(e.closest('[data-newsletter]'))).catch(() => false)) continue;
    const type = (await f.getAttribute('type')) || 'text';
    const inputmode = (await f.getAttribute('inputmode')) || '';
    const value = type === 'number' || /decimal|numeric/.test(inputmode) ? NUM_SENTINEL : `${TEXT_SENTINEL}${i}`;
    await f.fill(value).catch(() => {});
    await f.press('Tab').catch(() => {});
    typed++;
  }
  return typed;
}

for (const url of urls) {
  console.log(url);

  // 1 and 2.
  {
    const { context, page, all, google, blocked } = await open(url);
    const banner = await page.locator('.lpc').count();
    const storage = await page.evaluate(() => Object.keys(localStorage));
    const cookies = await context.cookies();
    if (banner === 1) ok('banner shown on first visit'); else fail('banner not shown on first visit');
    if (google.length === 0 && storage.length === 0 && cookies.length === 0) ok('before any click: no Google request, no cookie, no storage');
    else fail(`before any click: ${google.length} Google request(s), storage [${storage}], ${cookies.length} cookie(s)`);

    const before = await typeEverywhere(page);
    await page.click('.lpc-btn[data-choice="allow"]');
    await page.waitForTimeout(2500);
    const after = await typeEverywhere(page);
    await page.waitForTimeout(2500);
    const fieldCount = await page.locator('input, textarea').count();
    if (before + after > 0) ok(`typed a sentinel into ${after} field(s), before and after Allow`);
    else if (fieldCount === 0) ok('the page has no fields to type into');
    else fail('the page has fields, but none could be typed into');

    const tag = google.some((r) => r.url.startsWith('https://www.googletagmanager.com/gtag/js'));
    const hits = google.filter((r) => HIT.test(r.url)).length;
    if (tag && hits > 0) ok(`Allow: tag loaded, ${hits} hit(s)`); else fail(`Allow: tag ${tag}, hits ${hits}`);
    if (blocked.length === 0) ok('CSP permits the Google Analytics hosts'); else blocked.forEach((m) => fail(`CSP blocked: ${m}`));
    const leaked = all.filter((r) => leaks(r.url + r.body));
    if (leaked.length === 0) ok('no request, to any host, carries anything typed into the tool');
    else leaked.forEach((r) => fail(`typed value left the browser: ${r.url.slice(0, 140)}`));
    const ga = (await context.cookies()).filter((c) => c.name.startsWith('_ga'));
    if (ga.length && ga.every((c) => !c.domain.startsWith('.'))) ok(`GA cookies host-only: ${ga.map((c) => c.name).join(', ')}`);
    else fail(`GA cookies after Allow: ${ga.map((c) => `${c.name}@${c.domain}`).join(', ') || 'none'}`);

    // 3.
    const link = page.locator('[data-privacy-choices]').first();
    if (await link.count()) {
      await link.click();
      await page.waitForTimeout(300);
      await page.click('.lpc-btn[data-choice="decline"]');
      await page.waitForTimeout(300);
      if ((await context.cookies()).some((c) => c.name.startsWith('_ga'))) fail('GA cookies survived withdrawal'); else ok('withdrawal deletes the GA cookies');
      google.length = 0;
      await page.reload({ waitUntil: 'networkidle' });
      await page.waitForTimeout(800);
      if (google.length === 0) ok('after withdrawal, no Google request on the next load'); else fail(`after withdrawal: ${google.length} Google request(s)`);
    } else {
      fail('no Privacy choices link on the page');
    }
    await context.close();
  }

  // 5.
  {
    const { context, page, all } = await open(url);
    const subs = [];
    await page.route('**/api/subscribe', (route) => {
      const r = route.request();
      subs.push({ url: r.url(), method: r.method(), body: r.postData() || '' });
      route.fulfill({ status: 202, contentType: 'application/json', body: '{"status":"check_inbox"}' });
    });
    const form = page.locator('form[data-newsletter]');
    if (!(await form.isVisible().catch(() => false))) {
      fail('newsletter signup is not shown on this page');
    } else {
      await typeEverywhere(page);
      const toolField = page.locator('input:not([type=hidden]):not([type=checkbox]):not([type=radio]), textarea').first();
      await toolField.press('Enter').catch(() => {});
      await page.waitForTimeout(600);
      if (subs.length === 0) ok('signup: nothing sent on load or on Enter in a tool field');
      else fail(`signup: ${subs.length} request(s) to /api/subscribe before submitting`);
      const MARK = 'LIGANTNLMARK';
      const address = `reader.${MARK}@example.org`;
      await form.locator('input[name="email"]').fill(address);
      await form.locator('input[name="consent"]').check();
      await form.locator('button[type="submit"]').click();
      await page.waitForTimeout(800);
      const sent = subs[0];
      let body = null;
      try { body = JSON.parse(sent?.body || ''); } catch { body = null; }
      if (subs.length === 1 && sent.method === 'POST' && new URL(sent.url).origin === new URL(url).origin) ok('signup: one same-origin POST to /api/subscribe');
      else fail(`signup: ${subs.length} request(s), ${sent?.method} ${sent?.url}`);
      if (body && Object.keys(body).sort().join(',') === 'consent,email,website' && body.email === address && body.consent === true) ok('signup: body is the email, the consent and the honeypot, nothing else');
      else fail(`signup: unexpected body ${(sent?.body || '').slice(0, 120)}`);
      if (sent) { if (!leaks(sent.body)) ok('signup: nothing typed into the tool is in it'); else fail('signup: a tool value was sent with the signup'); }
      const elsewhere = all.filter((r) => (r.url + r.body).includes(MARK) && !r.url.includes('/api/subscribe'));
      if (elsewhere.length === 0) ok('signup: the address appears in no other request'); else elsewhere.forEach((r) => fail(`signup address sent to ${r.url.slice(0, 120)}`));
      if (/Check your inbox/.test(await form.locator('.footer-newsletter-status').textContent())) ok('signup: tells the reader to check their inbox');
      else fail('signup: no confirmation message shown');
    }
    await context.close();
  }

  // 4.
  {
    const { context, page, google } = await open(url, { gpc: true });
    if (await page.locator('.lpc').count() === 0 && google.length === 0) ok('GPC: no banner, no Google'); else fail('GPC was not treated as Decline');
    await context.close();
  }
  console.log('');
}

// 5. A copy someone runs themselves: the same build at a local address shows no
// banner and never contacts Google.
if (serveRoot) {
  console.log(`${LOCAL_COPY}/ (the same build, as a local copy)`);
  const { context, page, google } = await open(`${LOCAL_COPY}/`);
  if (await page.locator('.lpc').count() === 0 && google.length === 0) ok('local copy: no banner, no Google');
  else fail('a local copy showed the banner or contacted Google');
  const formShown = await page.locator('form[data-newsletter]').isVisible().catch(() => false);
  const linkShown = await page.locator('[data-newsletter-elsewhere]').isVisible().catch(() => false);
  if (!formShown && linkShown) ok('local copy: no signup form, a link to ligant.ai instead');
  else fail(`local copy: signup form ${formShown ? 'shown' : 'hidden'}, link ${linkShown ? 'shown' : 'hidden'}`);
  await context.close();
  console.log('');
}

await browser.close();
if (server) server.close();
if (failures) { console.error(`${failures} failure(s)`); process.exit(1); }
console.log('PASS');
