// The suite's privacy choice: Google Analytics, only if the visitor allows it.
//
// The same rules as ligant.ai's assets/consent.js, which is the reference
// implementation and carries the release checks:
//   - Nothing Google is requested before Allow. No Consent Mode, no pings:
//     before a click the tag does not exist.
//   - Nothing is stored before a click. After one, a single localStorage entry,
//     ligant_privacy_choice. A Global Privacy Control signal is a Decline.
//   - Allow and Decline look identical, and no close control counts as either.
//   - The footer's "Privacy choices" link reopens the banner. Withdrawing
//     deletes the GA cookies at once.
//   - page_location is origin plus path. Nothing a tool keeps in its query or
//     fragment, and nothing typed into it, is ever passed to the tag.
//
// Cloudflare Web Analytics is separate: it stores nothing on the device, runs
// for every visitor, and is not controlled here.
//
// Every tool gets this by rendering the suite footer: SuiteFooter and bindCopy
// call initConsent(). It is idempotent. It touches the DOM only when called, so
// the package still loads under plain Node.

import { PRIVACY_URL } from './index.js';

export const GA_ID = 'G-9V1GYE3KRX';
// One literal, so a tool's bundle scan can allow exactly this address.
export const GA_SCRIPT_URL = 'https://www.googletagmanager.com/gtag/js?id=G-9V1GYE3KRX';
export const CONSENT_KEY = 'ligant_privacy_choice';
// Bump when the banner's wording or what it controls changes: a stored choice
// from an older version is ignored, so the visitor is asked again. Kept equal
// to ligant.ai's, so both sites describe the same banner.
export const CONSENT_VERSION = '2026-09-29-ga';
export const BANNER_TEXT =
  'May we use Google Analytics to see which pages are used? It sets cookies and sends Google the pages you view and basic device information. If you are signed in to Google, Google may connect these visits to your account. It never receives anything you type into a tool, and everything on this site works the same either way.';

// Only the hosted pages ask, and only they can ever load Google Analytics. A
// copy someone runs themselves (npm run dev, a preview, the single-file build
// opened from disk) shows no banner and never contacts Google.
export const HOSTED = /(^|\.)ligant\.ai$|\.pages\.dev$/;

let started = false;

export function initConsent() {
  if (started || typeof window === 'undefined' || typeof document === 'undefined') return;
  if (!HOSTED.test(location.hostname)) return;
  started = true;

  const gpc = navigator.globalPrivacyControl === true;
  let gaLoaded = false;
  let banner = null;

  const readChoice = () => {
    try {
      const saved = JSON.parse(localStorage.getItem(CONSENT_KEY) || 'null');
      if (saved && saved.v === CONSENT_VERSION && (saved.choice === 'allow' || saved.choice === 'decline')) return saved.choice;
    } catch { /* unreadable or blocked storage is the same as no choice */ }
    return null;
  };
  const saveChoice = (choice) => {
    try { localStorage.setItem(CONSENT_KEY, JSON.stringify({ choice, v: CONSENT_VERSION })); } catch { /* holds for this page only */ }
  };

  const loadGA = () => {
    if (gaLoaded) return;
    gaLoaded = true;
    window.dataLayer = window.dataLayer || [];
    window.gtag = function gtag() { window.dataLayer.push(arguments); };
    window.gtag('js', new Date());
    const config = {
      cookie_domain: 'none',
      allow_ad_personalization_signals: false,
      page_location: location.origin + location.pathname,
    };
    if (document.referrer) config.page_referrer = document.referrer.split(/[?#]/)[0];
    window.gtag('config', GA_ID, config);
    const s = document.createElement('script');
    s.async = true;
    s.src = GA_SCRIPT_URL;
    document.head.appendChild(s);
  };

  const deleteGACookies = () => {
    const parts = location.hostname.split('.');
    const domains = [''];
    for (let i = 0; i < parts.length - 1; i++) domains.push(`; domain=.${parts.slice(i).join('.')}`);
    for (const c of document.cookie.split(';')) {
      const name = c.split('=')[0].trim();
      if (!/^_ga(_|$)|^_gid$|^_gat/.test(name)) continue;
      for (const d of domains) document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/${d}`;
    }
  };

  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text) n.textContent = text;
    return n;
  };

  const closeBanner = () => {
    if (!banner) return;
    banner.remove();
    banner = null;
    document.body.style.paddingBottom = '';
  };

  const choose = (choice) => {
    saveChoice(choice);
    if (choice === 'allow') loadGA();
    else deleteGACookies();
    closeBanner();
  };

  const showBanner = (reopened) => {
    if (banner) return;
    banner = el('div', 'lpc');
    banner.setAttribute('role', 'region');
    banner.setAttribute('aria-labelledby', 'lpc-title');
    const inner = el('div', 'lpc-inner');
    const title = el('p', 'lpc-title', 'Analytics cookies');
    title.id = 'lpc-title';
    inner.appendChild(title);
    inner.appendChild(el('p', 'lpc-text', BANNER_TEXT));
    if (reopened) {
      const current = readChoice();
      inner.appendChild(el('p', 'lpc-current', current === 'allow' ? 'Your current choice is Allow.'
        : current === 'decline' ? 'Your current choice is Decline.' : 'You have not made a choice yet.'));
    }
    const actions = el('div', 'lpc-actions');
    const allow = el('button', 'lpc-btn', 'Allow');
    allow.type = 'button';
    allow.setAttribute('data-choice', 'allow');
    allow.addEventListener('click', () => choose('allow'));
    const decline = el('button', 'lpc-btn', 'Decline');
    decline.type = 'button';
    decline.setAttribute('data-choice', 'decline');
    decline.addEventListener('click', () => choose('decline'));
    const policy = el('a', 'lpc-link', 'Privacy Policy');
    policy.href = `${PRIVACY_URL}#google-analytics`;
    actions.append(allow, decline, policy);
    inner.appendChild(actions);
    banner.appendChild(inner);
    // First in the document, so it is the first thing a keyboard reaches.
    document.body.insertBefore(banner, document.body.firstChild);
    // Never cover the end of the page: the banner is a notice, not a wall.
    document.body.style.paddingBottom = `${banner.offsetHeight}px`;
    if (reopened) allow.focus();
  };

  document.addEventListener('click', (e) => {
    const t = e.target instanceof Element ? e.target.closest('[data-privacy-choices]') : null;
    if (!t || gpc) return;
    e.preventDefault();
    closeBanner();
    showBanner(true);
  });

  const start = () => {
    const choice = gpc ? 'decline' : readChoice();
    if (choice === 'allow') loadGA();
    else if (choice === 'decline') deleteGACookies();
    else showBanner(false);
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
}
