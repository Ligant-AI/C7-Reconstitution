// React bindings for @ligant/bench-chrome. Thin by design: the markup is the
// same string the plain-JS tools render, so a React tool and a plain one cannot
// drift apart. Written with createElement rather than JSX so the package ships
// without a build step.
import { createElement, useEffect, useRef } from 'react';
import { bindCopy, markSvg, renderFooter, renderHeader } from './index.js';

/** `<header class="masthead">` with the suite's header inside. */
export function SuiteHeader(props) {
  return createElement('header', {
    className: 'masthead',
    dangerouslySetInnerHTML: { __html: renderHeader(props) },
  });
}

/** `<footer class="site-footer">` with the suite's footer inside, copy buttons wired. */
export function SuiteFooter(props) {
  const ref = useRef(null);
  useEffect(() => (ref.current ? bindCopy(ref.current) : undefined), []);
  return createElement('footer', {
    ref,
    className: 'site-footer',
    dangerouslySetInnerHTML: { __html: renderFooter(props) },
  });
}

/** The mark alone, for a colophon. `display: contents` keeps the wrapper out of layout. */
export function LigantMark({ size = 28, variant = 'tile', title = '' } = {}) {
  return createElement('span', {
    style: { display: 'contents' },
    dangerouslySetInnerHTML: { __html: markSvg({ size, variant, title }) },
  });
}
