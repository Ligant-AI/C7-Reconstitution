import type { FooterOptions, HeaderOptions, MarkOptions } from './index'

export declare function SuiteHeader(props: HeaderOptions): JSX.Element
export declare function SuiteFooter(props: FooterOptions): JSX.Element
export declare function LigantMark(props?: MarkOptions): JSX.Element
